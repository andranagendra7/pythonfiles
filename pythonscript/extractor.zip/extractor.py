from PyQt5.QtWidgets import (QApplication, QComboBox, QDialog,
        QDialogButtonBox, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout,
        QLabel, QLineEdit, QMenu, QMenuBar, QPushButton, QSpinBox, QTextEdit,
        QVBoxLayout,QMessageBox)
 
import sys
from PyQt5 import QtCore, QtGui
from os import getenv
import pymssql
import numpy as np
import pandas as pd
from pandas import DataFrame
import re
 
class Dialog(QDialog):
    NumGridRows = 4
    NumButtons = 4
 
    def __init__(self):
        super(Dialog, self).__init__()
        self.createFormGroupBox()
 
        buttonBox = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttonBox.accepted.connect(self.handleCalculate)
        buttonBox.rejected.connect(self.reject)
 
        mainLayout = QVBoxLayout()
        mainLayout.addWidget(self.formGroupBox)
        mainLayout.addWidget(buttonBox)
        self.setLayout(mainLayout)
 
        self.setWindowTitle("Mssql DB export")
 
    def createFormGroupBox(self):
        self.formGroupBox = QGroupBox("Settings")
        layout = QFormLayout()
        self.input1 = QLineEdit(self)
        self.input2 = QLineEdit(self)
        self.input3 = QLineEdit(self)
        self.input4 = QLineEdit(self)
        self.input6 = QLineEdit(self)		
        layout.addRow(QLabel("DB Host Name:"), self.input1)
        layout.addRow(QLabel("DB Username:"),self.input2)
        layout.addRow(QLabel("DB Password:"),self.input3)
        layout.addRow(QLabel("DB Name:"),self.input4)
        
        self.input5 = QTextEdit(self)
        #find_box = QLineEdit()

        # this layout is not of interest
        #layout = QVBoxLayout(self)
        

        # set a grid layout put stuff on the text area
        #self.setLayout(layout)

        text_layout= QGridLayout()

        # put find box in the top right cell (in a 2 by 2 grid) 
        #text_layout.addWidget(find_box, 0, 1)

        # set stretch factors to 2nd row and 1st column so they push the find box to the top right
        #text_layout.setColumnStretch(0, 1)
        #text_layout.setRowStretch(0, 1)

        self.input5.setLayout(text_layout)
        #layout.addWidget(text_area)		
        layout.addRow(QLabel("DB Query:"),self.input5)
        layout.addRow(QLabel("Excel File name"),self.input6)		
        self.formGroupBox.setLayout(layout)
		
    def handleCalculate(self):
        dbhostname = self.input1.text()
        dbusername = self.input2.text()
        dbpassword = self.input3.text()
        dbname = self.input4.text()	
        dbquery = self.input5.toPlainText()
        filename = self.input6.text()		
        #self.showMessageBox(x)
        #conn = pymssql.connect(dbhostname, dbusername, dbpassword, dbname)
        conn = pymssql.connect(server=dbhostname,user=dbusername,password=dbpassword,database=dbname)		
        cursor = conn.cursor()
        cursor.execute(dbquery)
        rows = cursor.fetchall()
        data = []
        res = pd.DataFrame(rows,columns = [column[0] for column in cursor.description])
        #res.to_excel(filename+'.xlsx',index=False,merge_cells=False,encoding='utf8')
        res.to_csv(filename+'.csv',index=False,encoding='utf8')
        conn.close()
        self.showMessageBox()		
		
    def showMessageBox(self):
        QMessageBox.information(self, 'Success ','Excel generated successfully')
		
 
if __name__ == '__main__':
    app = QApplication(sys.argv)
    dialog = Dialog()
sys.exit(dialog.exec_())