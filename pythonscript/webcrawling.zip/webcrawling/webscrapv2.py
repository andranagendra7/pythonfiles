import os
#import xml.etree.ElementTree as ET
import glob
import requests
import urllib3
urllib3.disable_warnings()
import string
import xml.dom.minidom
from lxml import etree
from lxml import cssselect, html
from datetime import datetime
import sys
from shutil import copyfile
from xml.dom import minidom
from bs4 import  BeautifulSoup
import xml.etree.ElementTree as ET
import re # for regular expression
import os.path



class mdict(dict):

    def __setitem__(self, key, value):
        """add the given value to the list of values for this key"""
        self.setdefault(key, []).append(value)

 
metadatadict = mdict()

def cleanhtml(raw_html):
  cleanr = re.compile('<.*?>')
  cleantext = re.sub(cleanr, '', raw_html)
  return cleantext

def remove_tags(text):
    ''.join(xml.etree.ElementTree.fromstring(text).itertext())

def get_redirected_url(url):
    
    http = urllib3.PoolManager()
    response = http.request('GET', url)
    print (response.data)
    return response.url
    
#get doi from input xml
def ReadDOIfromInputfile(Inputxml):
    try:
        tree = ET.parse(Inputxml)
        root = tree.getroot()
        #xmldoc=xml.dom.minidom.parse(Inputxml)
        #dois=xmldoc.getElementsByTagName('DOI')
        #for doi in dois:
            #doiinxml=doi.firstChild.data
        #for dois in root.findall('Citation'):
        doiinxml = root.find('DOI').text
        #clean_doi_xml = remove_tags(doiinxml)
        return (doiinxml)
        #return doiinxml
    except Exception as e:
        LogMessage(" ", "Info", "Exception in ReadDOIfromInputfile"+str(e))      



                

def ExtractSaeMetadata(url,Inputxml,PublisherName):
    try:
       
        GivenName=[]
        SurName=[]
        
        headers ={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36','Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' ,'Accept-Language': 'en-US,en;q=0.9'}
        responseContent = requests.get(url, headers=headers)
        Htmlcontent = responseContent.content
        #print(Htmlcontent)
        PublicationDate = html.fromstring(Htmlcontent).xpath("//meta[@name='citation_publication_date']")[0].attrib['content']
        #print("the publication date is" + repr(PublicationDate))
        matches = re.findall('(\d{4})\-\d*\-\d*', PublicationDate)
        for match in matches:            
            metadatadict['volume']=match  
        JournalTitle = html.fromstring(Htmlcontent).xpath("//meta[@name='citation_title']")[0].attrib['content']
        metadatadict['Title']=JournalTitle
       
        doi = html.fromstring(Htmlcontent).xpath("//meta[@name='citation_doi']")[0].attrib['content']
        metadatadict['DOI']=doi 
        #authors = driver.find_element_by_xpath('//meta[@name="citation_author"]').get_attribute("content")
        for i in html.fromstring(Htmlcontent).xpath("//meta[@name='citation_author']"):
            GivenName.append(i.attrib['content']) 
        #driver.quit()
        sourcetitle = html.fromstring(Htmlcontent).xpath("//meta[@name='citation_technical_report_institution']")[0].attrib['content']
        sourcenumber = html.fromstring(Htmlcontent).xpath("//meta[@name='citation_technical_report_number']")[0].attrib['content']
        metadatadict['Source']=(sourcetitle+' '+sourcenumber)
        totalcontent = ''
        for i in html.fromstring(Htmlcontent).xpath("//div[@class='nx-detail-item']"): 
            #print(i.text_content().findtext("Pages:").next())
            totalcontent = totalcontent + i.text_content()
        metadatadict['Page']= totalcontent[totalcontent.find("Pages")+1:].split()[1]    
        WritemetadataToXml(metadatadict,Inputxml,GivenName,'') 

 
    except Exception as e:
        LogMessage(" PublisherName", "Info", "Exception in ExtractMetadata"+str(e))         
        

def WritemetadataToXml(metadatadict,Inputxml,GivenNames,SurNames):
    try:
        #print("the metadict value is " + repr(metadatadict))
        #print("the inputxml value is " + repr(Inputxml))
        #print("the givennames value is " + repr(GivenNames))
        #print("the surnames value is " + repr(SurNames))
        ParentDirectory=os.path.dirname(Inputxml)
        Filename=os.path.splitext(os.path.basename(Inputxml))[0]       
        doc = minidom.Document()
        root = doc.createElement('Citation')
        AuthorNode=doc.createElement('AuthorGroup')
        #doc.appendChild(root)
        if(len(SurNames)>0):
            for i in range(0, len(GivenNames)):
                Namesnode=doc.createElement("Name")    
                GivennameNode=doc.createElement('GivenName')
                GivennameNode.appendChild(doc.createTextNode(GivenNames[i]))
                Namesnode.appendChild(GivennameNode)    
                SurnameNode=doc.createElement('SurName')
                SurnameNode.appendChild(doc.createTextNode(SurNames[i]))
                Namesnode.appendChild(SurnameNode)
                AuthorNode.appendChild(Namesnode)
                root.appendChild(AuthorNode)
                doc.appendChild(root)
        else:
            for i in range(0, len(GivenNames)):
                Namesnode=doc.createElement("Name") 
                Namesnode.appendChild(doc.createTextNode(GivenNames[i]))           
                AuthorNode.appendChild(Namesnode)
                root.appendChild(AuthorNode)
                doc.appendChild(root)
                
            
        
        for metadata, Nodevalue in metadatadict.items():    
            Nodename=doc.createElement(metadata)    
            metadatavalue=doc.createTextNode(Nodevalue[0])
            Nodename.appendChild(metadatavalue)
            root.appendChild(Nodename)
                
        xml_str = doc.toprettyxml(indent="  ")
        outputpath=ParentDirectory+'/'+Filename+'_output.xml'
        with open(outputpath, "w") as f:
            f.write(xml_str)
    except Exception as e:
        LogMessage(" ", "Info", "Exception in WritemetadatatoXml"+str(e))
                 
    

        
def GetWebpageResponse(url):
    try:
        r=requests.get(url)
        
        if("Elsevier" in r.url):
            return('Elsevier',r.content,r.status_code)
        elif('wiley' in r.url):
            return('wiley',r.content,r.status_code)
        elif('sae' in r.url):
            return('sae',r.content,r.status_code)
        else:
            return('None','',r.status_code)
        
    except Exception as e:
        LogMessage(" ", "Info", "Exception in Gettingwebpageresponse"+str(e))
        
def GetWebsitename(url):
    try:        
        if('www.sciencedirect.com' in url):
            return 'Elsevier'
        if('www.nature.com' in url):
            return 'Springer'
        if('onlinelibrary.wiley.com' in url):
            return 'Wiley'
        if('www.hindawi.com' in url):
            return 'Hindawi'
        if('articles.sae.org' in url):
            return'SAE'  
    except Exception as e:
        LogMessage(" ", "Info", "Exception in GetWebsitename"+str(e))
                  
        
        
                        
        
def LogMessage(Chapterid, MessageType, Message):          
    Logpath=os.getcwd()+'/'+datetime.now().strftime('%d-%m-%Y')
    if(not os.path.isdir(Logpath)):
        os.makedirs(Logpath)
        f = open(Logpath+ '/errorlog.txt', 'w')
        period = str(datetime.now())
        f.write(period +':'+ Message + '\r\n')
        f.close()
    else:
        
        f = open(Logpath+ '/errorlog.txt','a')
        period = str(datetime.now())
        f.write(period +':'+ Message + '\r\n')
        f.close()
           
               
def urlnotfound(Errormsg):
    ParentDirectory=os.path.dirname(Inputxml)
    Filename=os.path.splitext(os.path.basename(Inputxml))[0]
    errordoc = minidom.Document()
    errorroot = errordoc.createElement("Citation")
    errorNodename=errordoc.createElement("Error")    
    errordatavalue=errordoc.createTextNode(Errormsg)
    errorNodename.appendChild(errordatavalue)
    errorroot.appendChild(errorNodename)
    errordoc.appendChild(errorroot)
    errorstring = errordoc.toprettyxml(indent="  ")
    outputpath=ParentDirectory+'/'+Filename+'_output.xml'
    f = open(outputpath, 'w+')
    f.write(errorstring)
    f.close()
    

        
DOI=[]
inputxml_path = str(sys.argv[1])
Inputxml = inputxml_path
if Inputxml:
    check_path = os.path.isfile(Inputxml)
    if check_path: 
        #DOI=ReadDOIfromInputfile(Inputxml)
        DOI="10.4271/2011-01-1626"

        url="https://doi.org/"+str(DOI)
        (Websitename,PageResponseContent,statuscode)=GetWebpageResponse(url)
        
        if(statuscode == 200):
            if(Websitename=="sae"):
                ExtractSaeMetadata(url,Inputxml,"sae")
            else:
                urlnotfound("Invalid DOI")
        else:
            urlnotfound("404 or url not found")
            
    else:
        LogMessage(" ", "Info", "File not found or invalid xml")
else:
    LogMessage(" ", "Info", "No proper Input path")            
        
